<?php
echo json_encode(phpversion());
?>